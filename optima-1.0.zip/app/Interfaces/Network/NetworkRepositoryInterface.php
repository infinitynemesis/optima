<?php

namespace App\Interfaces\Network;

interface NetworkRepositoryInterface
{
    public function get();
}
