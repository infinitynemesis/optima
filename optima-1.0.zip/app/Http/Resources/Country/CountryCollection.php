<?php

namespace App\Http\Resources\Country;

use App\Http\Resources\ApiCollection;

class CountryCollection extends ApiCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
