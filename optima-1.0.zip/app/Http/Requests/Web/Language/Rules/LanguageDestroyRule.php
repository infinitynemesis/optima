<?php

namespace App\Http\Requests\Web\Language\Rules;

use App\Repositories\Language\LanguageRepository;
use Illuminate\Contracts\Validation\Rule;

class LanguageDestroyRule implements Rule
{
    protected $error;

    /**
     * Determine if the validation rule passes.
     *
     * @param  string $attribute
     * @param  string $uuid
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $languageRepository = new LanguageRepository();
        $count = $languageRepository->count();

        if($count == 1) {
            $this->error = 'At least one site language should be specified';
            return false;
        }

        $language = $languageRepository->getById($value);

        if($language->is_default) {
            $this->error = 'Default Site Language can not be removed';
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return $this->error;
    }
}
