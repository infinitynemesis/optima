<?php

const KYC_DOCUMENT_STATUS_PENDING = 'pending';
const KYC_DOCUMENT_STATUS_APPROVED = 'approved';
const KYC_DOCUMENT_STATUS_REJECTED = 'rejected';
