<?php

const DEPOSIT_CONFIRMED = 'confirmed';
const DEPOSIT_PENDING = 'pending';
const DEPOSIT_IGNORED = 'ignored';

const FIAT_DEPOSIT_CONFIRMED = 'confirmed';
const FIAT_DEPOSIT_PENDING = 'pending';
const FIAT_DEPOSIT_REJECTED = 'rejected';
