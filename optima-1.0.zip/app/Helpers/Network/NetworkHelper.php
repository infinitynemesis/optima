<?php

const NETWORK_COINPAYMENTS = 1;
const NETWORK_ETH = 2;
const NETWORK_ERC = 3;
const NETWORK_BANK = 4;
