<?php

namespace App\Services\PaymentGateways\Coin\Coinpayments\Model;

use Illuminate\Database\Eloquent\Model;

class CoinpaymentsCurrency extends Model
{
    protected $guarded = [];
}
